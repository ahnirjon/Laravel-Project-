<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Student extends Model
{
    //protected $table = 'my_flights';
	protected $primaryKey = 'studentId';
	
    public $timestamps = false;
}
