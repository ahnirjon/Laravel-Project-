<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Teacher extends Model
{
    //protected $table = 'my_flights';
	protected $primaryKey = 'teacherId';
	
    public $timestamps = false;
}
