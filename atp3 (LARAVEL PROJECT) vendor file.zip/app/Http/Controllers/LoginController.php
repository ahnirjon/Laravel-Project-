<?php

namespace App\Http\Controllers;

session_start();

use Illuminate\Http\Request;

use App\Models\Login;

class LoginController extends Controller
{
    public function verify(Request $request)
    {
    	$email = $request->email;
    	$password = $request->password;

    	$login = new Login;

    	$u = $login->where([
					       'email' => $email,
					       'password' => $password
						])->first();

    	if($u != null)
    	{
    		$temp = $request->session()->put('loggedUser', $u);

    		return redirect()->route('admin.home');
    	}
    	else
    	{
    		return view('index');
    	}
    }

    public function sessionRemove()
    {
    	session()->flush();
    	session_destroy();

		//var_dump($count);
    	return redirect()->route('index');
    }
}
