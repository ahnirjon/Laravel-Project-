<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Teacher;
use App\Models\Login;

class TeacherController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('teacher.teacher');
    }

    public function teacherList()
    {
        $teachers = Teacher::all();

        return view('teacher.teacherlist',['teachers' => $teachers]);
    }

    public function addTeacher()
    {
        return view('teacher.addteacher');
    }

    public function updateTeacher(Request $req)
    {
        $teacher = Teacher::where('teacherId','=',$req->id)->first();

        $teacher->teacherName = $req->name;
        $teacher->teacherEmail = $req->email;
        $teacher->teacherPhone = $req->phone;
        $teacher->save();

        return redirect()->route('admin.teacherList');
    }

    public function addTeacherDetails(Request $req)
    {
        $login = new Login;
        $teacher = new Teacher;

        $teacher->teacherName = $req->name;
        $teacher->teacherEmail = $req->email;
        $teacher->teacherPhone = $req->phone;
        $teacher->save();

        $login->email = $req->email;
        $login->password = $req->password;
        $login->typeid = 2;
        $login->save();

        return redirect()->route('admin.teacherList');
    }

    public function deleteTeacher(Request $req)
    {
        $t = Teacher::where('teacherId','=',$req->id)->first();

        $t->delete();

        return redirect()->route('admin.teacherList');
    }

    public function editTeacher(Request $req)
    {

        $t = Teacher::where('teacherId','=',$req->id)->first();
               
        return view('teacher.teacherlist',['teachers' => null, 'teacher' => $t]);
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
