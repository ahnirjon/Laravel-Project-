<?php

namespace App\Http\Controllers;
use App\Models\Student;
use Illuminate\Http\Request;

class StudentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('student.student');
    }

    public function studentList()
    {
         $students = Student::all();
      //  return view('student.studentlist');
        return view('student.studentlist',['students' => $students]);
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    public function deleteStudent(Request $req)
    {
        $s = Student::where('studentId','=',$req->id)->first();

        $s->delete();

        return redirect()->route('admin.studentList');
    }


    public function updateStudent(Request $req)
    {
        $student = Student::where('studentId','=',$req->id)->first();

        $student->studentName = $req->name;
        $student->studentEmail = $req->email;
        $student->studentPhone = $req->phone;
       
        $student->save();

        return redirect()->route('admin.studentList');
    }

      public function editStudent(Request $req)
    {

        $student = Student::where('studentId','=',$req->id)->first();
               
        return view('student.studentList',['students' => null, 'student' => $student]);
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
