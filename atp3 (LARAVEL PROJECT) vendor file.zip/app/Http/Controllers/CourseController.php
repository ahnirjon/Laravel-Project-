<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Course;

class CourseController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('course.course');
    }

    public function addCourse()
    {
        return view('course.addcourses');
    }

    public function courseList()
    {
         $courses = Course::all();
     

        return view('course.courselist',['courses' => $courses]);

    }
    public function addCourseDetails(Request $req)
    {
        
        $courses = new Course;

        $courses->courseTitle = $req->coursename;
        $courses->departmentName = $req->Department;
       
        $courses->save();

       

        return redirect()->route('admin.addCourse');
    }

    public function updateCourse(Request $req)
    {
        $course = Course::where('courseId','=',$req->id)->first();

        $course->courseTitle = $req->coursename;
        $course->departmentName = $req->Department;
       
        $course->save();

        return redirect()->route('admin.courseList');
    }

      public function editCourse(Request $req)
    {

        $course = Course::where('courseId','=',$req->id)->first();
               
        return view('course.courseList',['courses' => null, 'course' => $course]);
    }

     public function deleteCourse(Request $req)
    {
        $c = Course::where('courseId','=',$req->id)->first();

        $c->delete();

        return redirect()->route('admin.courseList');
    }

    public function approveCourse(Request $req)
    {

        $course = Course::where('courseId','=',$req->courseId)->first();
        
        $course->approved = 1;
        $course->save();

        return ['status' => 'success'];
    }

    public function revokeCourse(Request $req)
    {

        $course = Course::where('courseId','=',$req->courseId)->first();
               
        $course->approved = 0;
        $course->save();

        return ['status' => 'success'];
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
