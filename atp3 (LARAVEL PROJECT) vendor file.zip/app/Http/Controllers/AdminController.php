<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Login;
use App\Models\Course;
use App\Models\Department;
use App\Models\Teacher;
use App\Models\Student;


class AdminController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if(session('loggedUser') != null)
        {
            if (session('loggedUser')->typeid == 1)
            {

                $c = Course::count();
                $d = Department::count();
                $t = Teacher::count();
                $s = Student::count();

                return view('admin.admin',['courses' => $c, 'departments' => $d, 'teachers' => $t, 'students' => $s]);
            }else{
                return redirect()->route('logout');
            }
        }
    }

    public function profile()
    {
        return view('admin.profile');
    }

    public function profileUpdate(Request $req)
    {
        $validatedData = $req->validate([
            'oldPassword' => 'required',
            'password' => 'required|min:2'
        ]);

        if (session('loggedUser')->password == $req->oldPassword) {
            $u = Login::where('email','=', session('loggedUser')->email)->first();

            $u->password = $req->password;
            $u->save();

            return redirect()->route('logout');

        }else{
            return redirect()->route('admin.profile');
        }

    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
