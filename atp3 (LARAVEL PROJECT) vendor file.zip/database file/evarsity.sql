-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 17, 2019 at 11:32 PM
-- Server version: 10.3.15-MariaDB
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `evarsity`
--

-- --------------------------------------------------------

--
-- Table structure for table `assignment`
--

CREATE TABLE `assignment` (
  `assignmentId` int(11) NOT NULL,
  `courseId` int(10) NOT NULL,
  `teacherName` varchar(30) NOT NULL,
  `assignmentPdf` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `assignment`
--

INSERT INTO `assignment` (`assignmentId`, `courseId`, `teacherName`, `assignmentPdf`) VALUES
(36, 39, 'Tahia Karim', 'assignments/DC_EXP_2_STUDENT_MANUAL.pdf'),
(37, 40, 'Shihab Sakib', 'assignments/12 How to write the Introduction of a Report.pdf'),
(38, 40, 'Shihab Sakib', 'assignments/Capacitors & Inductors.pdf'),
(39, 41, 'Debashish Kumar', 'assignments/Complex variable Lec-6.pdf'),
(40, 41, 'Debashish Kumar', 'assignments/Complex variable lec-7.pdf'),
(41, 42, 'Mostafizur Rahman', 'assignments/Complex variable week-4.pdf');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `courseId` int(11) NOT NULL,
  `courseTitle` varchar(100) NOT NULL,
  `approved` int(1) NOT NULL DEFAULT 0,
  `departmentName` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`courseId`, `courseTitle`, `approved`, `departmentName`) VALUES
(43, 'alzebrA', 1, 'mathematics');

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `departmentId` int(5) NOT NULL,
  `departmentTitle` varchar(20) NOT NULL,
  `departmentTeacher` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`departmentId`, `departmentTitle`, `departmentTeacher`) VALUES
(2, 'history', 'john F kennedy'),
(3, 'english', 'john f kennedy'),
(4, 'biology', 'bush');

-- --------------------------------------------------------

--
-- Table structure for table `exams`
--

CREATE TABLE `exams` (
  `examsId` int(11) NOT NULL,
  `courseId` int(10) NOT NULL,
  `teacherName` varchar(30) NOT NULL,
  `questionPdf` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exams`
--

INSERT INTO `exams` (`examsId`, `courseId`, `teacherName`, `questionPdf`) VALUES
(30, 39, 'Tahia Karim', 'exams/Problem Sheet.pdf'),
(31, 40, 'Shihab Sakib', 'exams/12 How to write the Introduction of a Report.pdf'),
(32, 40, 'Shihab Sakib', 'exams/DC_EXP_3_STUDENT_MANUAL.pdf'),
(33, 41, 'Debashish Kumar', 'exams/M-3 Set A ( Midterm Fall 2016-17).pdf'),
(34, 41, 'Debashish Kumar', 'exams/M-3 SetA (Final_Fall_2016-17).pdf'),
(35, 42, 'Mostafizur Rahman', 'exams/Q2_sol.pdf');

-- --------------------------------------------------------

--
-- Table structure for table `lecturenotes`
--

CREATE TABLE `lecturenotes` (
  `lectureNotesId` int(11) NOT NULL,
  `courseId` int(10) NOT NULL,
  `teacherName` varchar(30) NOT NULL,
  `lectureNote` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lecturenotes`
--

INSERT INTO `lecturenotes` (`lectureNotesId`, `courseId`, `teacherName`, `lectureNote`) VALUES
(27, 39, 'Tahia Karim', 'notes/Q1_sol.pdf'),
(28, 40, 'Shihab Sakib', 'notes/Problem Sheet.pdf'),
(29, 41, 'Debashish Kumar', 'notes/Complex variable Lec-6.pdf'),
(30, 42, 'Mostafizur Rahman', 'notes/magnetic circuits.pdf');

-- --------------------------------------------------------

--
-- Table structure for table `logins`
--

CREATE TABLE `logins` (
  `logid` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(30) NOT NULL,
  `typeid` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `logins`
--

INSERT INTO `logins` (`logid`, `email`, `password`, `typeid`) VALUES
(22, 'admin@gmail.com', '1234', 1),
(41, 'tahiakarim@gmail.com', '1@', 2),
(46, 'expertmen14@gmail.com', '1', 2),
(47, 'munjirul.kabir1997@gmail.com', '123', 3);

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `messageId` int(11) NOT NULL,
  `messageFrom` varchar(30) NOT NULL,
  `messageTo` varchar(30) NOT NULL,
  `messageDetail` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`messageId`, `messageFrom`, `messageTo`, `messageDetail`) VALUES
(1, 's@gmail.com', 'dk@gmail.com', 'sir ami achi'),
(2, 'dk@gmail.com', 's@gmail.com', 'khub bhalo');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `studentId` int(11) NOT NULL,
  `studentName` varchar(30) NOT NULL,
  `studentEmail` varchar(30) NOT NULL,
  `studentPhone` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`studentId`, `studentName`, `studentEmail`, `studentPhone`) VALUES
(1, 'Amar ', 'amar@gmail.com', '01921882735'),
(2, 'Akbar', 'akbar@gmail.com', '01727241030'),
(3, 'Anthony', 'anthony@yahoo.com', '01552353580'),
(7, 'hello', 'jop@gmail.com', '+88017673367');

-- --------------------------------------------------------

--
-- Table structure for table `syllabus`
--

CREATE TABLE `syllabus` (
  `syllabusId` int(11) NOT NULL,
  `courseMeetingTimeLecture` varchar(200) NOT NULL,
  `courseMeetingTimeReaction` varchar(200) NOT NULL,
  `prerequisites` varchar(200) NOT NULL,
  `descrip` varchar(2000) NOT NULL,
  `assOrExams` varchar(100) NOT NULL,
  `teacherName` varchar(30) NOT NULL,
  `courseId` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `syllabus`
--

INSERT INTO `syllabus` (`syllabusId`, `courseMeetingTimeLecture`, `courseMeetingTimeReaction`, `prerequisites`, `descrip`, `assOrExams`, `teacherName`, `courseId`) VALUES
(16, '3 Hours', '1.5 Hours', 'None', 'This is the first in a series of courses on Electric Circuits, and is one of the fundamental courses for anyone who wishes to study electrical engineering.', '2/1', 'Tahia Karim', 39),
(17, '3 Hours', '1.5 Hours', 'None', 'English level 1 basic is for people with little or no experience of the English language.', '2/2', 'Shihab Sakib', 40),
(18, '3 Hours', '1.5 Hours', 'None', 'This half course develops basic mathematical methods and will emphasise their applications to problems in economics, management and related areas.', '2/2', 'Debashish Kumar', 41),
(19, '3 Hours', '1.5 Hours', 'None', 'None', '1/1', 'Mostafizur Rahman', 42);

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

CREATE TABLE `teachers` (
  `teacherId` int(11) NOT NULL,
  `teacherName` varchar(30) NOT NULL,
  `teacherEmail` varchar(30) NOT NULL,
  `teacherPhone` varchar(14) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`teacherId`, `teacherName`, `teacherEmail`, `teacherPhone`) VALUES
(10, 'Shihab Sakibssssssss', 'ss@gmail.com', '+8801790909090'),
(11, 'Debashish Kumar', 'dk@gmail.com', '+8801231231231'),
(12, 'Mostafizur Rahman', 'mr@gmail.com', '+8801233211233'),
(15, 'ironman', 'ironman@gmail.com', '45678901212'),
(16, 'sir test', 'test@gmail.com', '0987654321'),
(17, 'alamin sir', 'alaminsir@gmail.com', '+88017676767'),
(19, 'shemeen', 'expertmen14@ymail.com', '354678');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `uid` int(11) NOT NULL,
  `firstName` varchar(30) NOT NULL,
  `lastName` varchar(30) NOT NULL,
  `dob` varchar(30) NOT NULL,
  `gender` varchar(6) NOT NULL,
  `phnNo` varchar(14) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`uid`, `firstName`, `lastName`, `dob`, `gender`, `phnNo`, `email`, `password`) VALUES
(39, 'student', 'ami', '2019-04-10', 'Male', '+8806666677698', 's@gmail.com', '1@');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `assignment`
--
ALTER TABLE `assignment`
  ADD PRIMARY KEY (`assignmentId`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`courseId`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`departmentId`);

--
-- Indexes for table `exams`
--
ALTER TABLE `exams`
  ADD PRIMARY KEY (`examsId`);

--
-- Indexes for table `lecturenotes`
--
ALTER TABLE `lecturenotes`
  ADD PRIMARY KEY (`lectureNotesId`);

--
-- Indexes for table `logins`
--
ALTER TABLE `logins`
  ADD PRIMARY KEY (`logid`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`messageId`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`studentId`);

--
-- Indexes for table `syllabus`
--
ALTER TABLE `syllabus`
  ADD PRIMARY KEY (`syllabusId`);

--
-- Indexes for table `teachers`
--
ALTER TABLE `teachers`
  ADD PRIMARY KEY (`teacherId`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`uid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `assignment`
--
ALTER TABLE `assignment`
  MODIFY `assignmentId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `courseId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `departmentId` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `exams`
--
ALTER TABLE `exams`
  MODIFY `examsId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `lecturenotes`
--
ALTER TABLE `lecturenotes`
  MODIFY `lectureNotesId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `logins`
--
ALTER TABLE `logins`
  MODIFY `logid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `messageId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `studentId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `syllabus`
--
ALTER TABLE `syllabus`
  MODIFY `syllabusId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `teachers`
--
ALTER TABLE `teachers`
  MODIFY `teacherId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
