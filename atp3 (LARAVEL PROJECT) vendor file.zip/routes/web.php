<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });


Route::get('/', 'IndexController@index')->name('index');

	
Route::post('/login', 'LoginController@verify')->name('login.verify');
Route::get('/logout', 'LoginController@sessionRemove')->name('logout');

Route::post('/registraion', 'IndexController@registration')->name('registration');



Route::group(['middleware' => ['loginCheck']], function(){


/////--------------------- Admin --------------------------
	Route::get('/adminHome', 'AdminController@index')->name('admin.home');

	Route::get('/adminTeacher', 'TeacherController@index')->name('admin.teacher');
	Route::get('/adminTeacherList', 'TeacherController@teacherList')->name('admin.teacherList');
	Route::get('/adminAddTeacher', 'TeacherController@addTeacher')->name('admin.addTeacher');
	Route::post('/adminAddTeacher', 'TeacherController@addTeacherDetails')->name('admin.addTeacher');
	Route::get('/adminDeleteTeacher', 'TeacherController@deleteTeacher')->name('admin.teacherDelete');
	Route::get('/adminEditTeacher', 'TeacherController@editTeacher')->name('admin.teacherEdit');
	Route::post('/adminUpdateTeacher', 'TeacherController@updateTeacher')->name('admin.updateTeacher');




	Route::get('/adminStudent', 'StudentController@index')->name('admin.student');
	Route::get('/adminStudentList', 'StudentController@studentList')->name('admin.studentList');
	Route::get('/adminDeleteStudent', 'StudentController@deleteStudent')->name('admin.studentDelete');
	Route::get('/adminEditStudent', 'StudentController@editStudent')->name('admin.studentEdit');
	Route::post('/adminUpdateStudent', 'StudentController@updateStudent')->name('admin.updateStudent');


	Route::get('/adminCourses', 'CourseController@index')->name('admin.course');
	Route::get('/adminAddCourses', 'CourseController@addCourse')->name('admin.addCourse');
	Route::get('/adminCoursesList', 'CourseController@courseList')->name('admin.courseList');
	Route::post('/adminAddCourses', 'CourseController@addCourseDetails')->name('admin.addCourse');
	Route::get('/adminDeleteCourses', 'CourseController@deleteCourse')->name('admin.courseDelete');
	Route::get('/adminEditCourse', 'CourseController@editCourse')->name('admin.courseEdit');
	Route::post('/adminUpdateCourse', 'CourseController@updateCourse')->name('admin.updateCourse');

	Route::get('/adminApproveCourse', 'CourseController@approveCourse');
	Route::get('/adminRevokeCourse', 'CourseController@revokeCourse');


	Route::get('/adminProfile', 'AdminController@profile')->name('admin.profile');
	Route::post('/adminProfile', 'AdminController@profileUpdate')->name('admin.profile');


	Route::get('/adminDepartment', 'DepartmentController@index')->name('admin.department');
	Route::get('/adminAddDepartment', 'DepartmentController@addDepartment')->name('admin.addDepartment');
	Route::get('/adminDepartmentList', 'DepartmentController@departmentList')->name('admin.departmentList');
	Route::post('/adminAddDepartment', 'DepartmentController@addDepartmentDetails')->name('admin.addDepartment');
	Route::get('/adminDeleteDepartment', 'DepartmentController@deleteDepartment')->name('admin.departmentDelete');
	Route::get('/adminEditDepartment', 'DepartmentController@editDepartment')->name('admin.departmentEdit');
	Route::post('/adminUpdateDepartment', 'DepartmentController@updateDepartment')->name('admin.updateDepartment');


});