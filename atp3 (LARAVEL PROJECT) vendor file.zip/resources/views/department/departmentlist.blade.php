<!DOCTYPE html>
<html lang="en">
  <head>
    <title>E-Varsity</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    
    
    <!-- <link href="https://fonts.googleapis.com/css?family=Muli:300,400,700,900" rel="stylesheet"> -->
    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/jquery-ui.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">

    <link rel="stylesheet" href="css/jquery.fancybox.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">

    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/style.css">
    
  </head>
  <body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">
  
  <div class="site-wrap">

    <div class="site-mobile-menu site-navbar-target">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div>
   
    
    <header class="site-navbar py-4 js-sticky-header site-navbar-target" role="banner">
      
      <div class="container-fluid">
        <div class="d-flex align-items-center">
          <div class="site-logo mr-auto w-25"><a href="index.html">E-Varsity</a></div>

        

          
        </div>
      </div>
      
    </header>

    <div class="intro-section single-cover" id="home-section">
      
      <div class="slide-1 " style="background-image: url('images/img_2.jpg');" data-stellar-background-ratio="0.5">
        <div class="container">
          <div class="row align-items-center">
            <div class="col-12">
              <div class="row justify-content-center align-items-center text-center">
                <div class="col-lg-6">
                  <h1 data-aos="fade-up" data-aos-delay="0">Department List</h1>
                 <div class="container">
  
  <p>Type something in the input field to search the table for Department name:</p>  
  <input class="form-control" id="myInput" type="text" placeholder="Search..">
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
   @if($departments != null)
  <table class="table table-bordered table-striped">
    <thead>
      <tr>
        <th>Department Title</th>
        <th>Department Teacher</th>
         <th>Operations</th>         
      </tr>
    </thead>
    <tbody id="myTable">
     
        @foreach($departments as $t)
        <tr>
          <td>{{$t->departmentTitle}}</td>
          <td>{{$t->departmentTeacher}}</td>
           <td>
            <a href="{{route('admin.departmentEdit', ['id' => $t->departmentId])}}" style="color: green;">Edit</a> 
            <a href="{{route('admin.departmentDelete', ['id' => $t->departmentId])}}" style="color: red;">Delete</a>
          </td>
        </tr>
        @endforeach
         @else
          <form class="form-horizontal" action="{{route('admin.updateDepartment')}}" method="post">
                            @csrf

                            <input type="hidden" name="id" value="{{$department->departmentId}}">
                            <div class="form-group">
                              <label class="control-label col-sm-2" for="email">Department Name:</label>
                              <div class="col-sm-10">
                                <input type="name" class="form-control" id="name" placeholder="Enter Name" name="name" value="{{$department->departmentTitle}}">
                              </div>
                            </div>
                            <div class="form-group">
                              <label class="control-label col-sm-2" for="email">Dept Teacher:</label>
                              <div class="col-sm-10">
                                <input type="name" class="form-control" id="email" placeholder="Enter Name" name="departmentTeacher" value="{{$department->departmentTeacher}}">
                              </div>
                            </div>
                         
                            <div class="form-group">        
                                                         </div>
                            <div class="form-group">        
                              <div class="col-sm-offset-2 col-sm-10">
                                <button type="submit" class="btn btn-default">Update</button>
                              </div>
                            </div>
                          </form>
      @endif
    </tbody>
  </table>
  
  <p>Note that we start the search in tbody, to prevent filtering the table headers.</p>
</div>

<script>
$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>



                </div>

                
              </div>
            </div>
            
          </div>
        </div>
      </div>
    </div>
    
   

  
    
  </div> <!-- .site-wrap -->

  <script src="js/jquery-3.3.1.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/jquery-ui.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/jquery.countdown.min.js"></script>
  <script src="js/bootstrap-datepicker.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.fancybox.min.js"></script>
  <script src="js/jquery.sticky.js"></script>

  
  <script src="js/main.js"></script>
    
  </body>
</html>